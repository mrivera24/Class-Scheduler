//
//  Constants.swift
//  Class Scheculer
//
//

// - MARK: Keys
let kParseApplicationId = "nOHm9yX1wVIbTd1AsVOvrq4AAWPBagZxeQXd5iI5"
let kParseClientId = "WvKzy2NVCHjYYgSkbTxlFEwD1YW09Dc4oOGf1QiV"

// - MARK: Settings TableView Constants
let kSettingsProfileSectionIndex = 0
let kSettingsLogoutSectionIndex = 1

let kSettingsProfileRowChangeEmailIndex = 0
let kSettingsProfileRowChangePasswordIndex = 1
let kSettingsProfileRowChangeAcademicProgramIndex = 2

let kSettingsLogoutRowIndex = 0

let kSettingsTotalProfileRows = 3
let kSettingsTotalLogoutRows = 1

let kProfileCellidentifier = "profileCell"
let kLogoutCellidentidier = "logoutCell"
let kCellidentifier = "myCell"

// - MARK: URLs
let kPUPRNewsURL = "www.pupr.edu/news"