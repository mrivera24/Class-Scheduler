//
//  SignupViewController.swift
//  Class Scheculer
//


import UIKit

class SignupViewController: UIViewController, UITextFieldDelegate, AcademicProgramSelectionTableViewControllerDelegate {
    
    var user:User = User()
    
    @IBOutlet weak var firstNameField: UITextField!
    @IBOutlet weak var lastNameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var submitButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.submitButton.layer.cornerRadius = 5
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Textfield delegate methods
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        self.firstNameField.resignFirstResponder()
        self.lastNameField.resignFirstResponder()
        self.emailField.resignFirstResponder()
        self.passwordField.resignFirstResponder()
        
        return true
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }

    @IBAction func submitButtonTapped(sender: AnyObject) {
        
        guard let firstName = firstNameField.text where !firstName.isEmpty else {
            
            return
        }
        
        guard let lastName = lastNameField.text where !lastName.isEmpty else {
            
            return
        }
        
        guard let email = emailField.text where !email.isEmpty else {
            
            return
        }
        
        guard let password = passwordField.text where !password.isEmpty else {
            
            return
        }
        
        
        self.user.firstName = firstName
        self.user.lastName = lastName
        self.user.email = email
        self.user.password = password
        
        // perform segue to select academic program
        // segueID = "academicProgramSegue"
        self.performSegueWithIdentifier("academicProgramSegue", sender: self)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if (segue.identifier == "academicProgramSegue") {
            
            let academicProgramSelectionVC = segue.destinationViewController as! AcademicProgramSelectionTableViewController
            
            academicProgramSelectionVC.delegate = self
            academicProgramSelectionVC.user = User(user: self.user)
        }
    }
    
    
    
    func academicProgramSelectionDidRegisterUser(controller: AcademicProgramSelectionTableViewController) {
        
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
}
