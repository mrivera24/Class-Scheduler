//
//  userPasswordUpdateViewController.swift
//  Class Scheculer
//
//  Created by Miguel Rivera on 5/18/16.


import UIKit
import Parse

class userPasswordUpdateViewController: UIViewController {

    
    @IBOutlet var userPasswordUpdateTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func submitButtonTapped(sender: AnyObject) {
        
        let userPassword = userPasswordUpdateTextField.text
        if userPassword!.isEmpty
        {
            let userMessage:String = "please type in your password"
            displayMessage(userMessage)
            return
        }
        
        let user = PFUser.currentUser()
        user?.setObject(userPassword!, forKey: "password")
        
        user?.saveInBackgroundWithBlock { (success, error) in
            
            if (error == nil) {
                
                let userMessage:String = "The update was successful."
                self.displayMessage(userMessage)
                
            } else {
                let userMessage:String = "Update email error. Please try again."
                self.displayMessage(userMessage)
            }
        }

        
    }
    
    
    @IBAction func cancelButtonTapped(sender: AnyObject) {
        
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    
    
    func displayMessage(userMessage:String){
        let myAlert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: UIAlertControllerStyle.Alert)
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
            action in
            self.dismissViewControllerAnimated(true, completion: nil)
        }
        
        myAlert.addAction(okAction)
        self.presentViewController(myAlert, animated: true, completion: nil)
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
