//
//  User.swift
//  Class Scheculer
//


import Parse
import UIKit

class User: NSObject {
    
    var firstName:String = ""
    var lastName:String = ""
    var email:String = ""
    var password:String = ""
    var academicProgram:AcademicPrograms = AcademicPrograms(id: "", name: "")
    
    override init() {
        
    }
    
    // Init with another user (AKA Copy Constructor)
    init(user:User) {
        
        self.firstName = user.firstName
        self.lastName = user.lastName
        self.email = user.email
        self.password = user.password
        self.academicProgram = user.academicProgram
    }
    
    init(parseUser:PFUser) {
        
        self.firstName = parseUser["first_name"] as! String
        self.lastName = parseUser["last_name"] as! String
        self.email = parseUser.email!
        self.academicProgram = AcademicPrograms(id: "", name: "")
    }
}
