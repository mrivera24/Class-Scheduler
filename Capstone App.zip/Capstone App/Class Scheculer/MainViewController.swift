//
//  MainViewController.swift
//  Class Scheculer
//


import Parse
import UIKit

class MainViewController: UIViewController {
    
    let user = PFUser.currentUser()
    let userFirstName = PFUser.currentUser()?.objectForKey("first_name") as? String
    let userLastName = PFUser.currentUser()?.objectForKey("last_name") as? String

    @IBOutlet var userName: UILabel!
    
    @IBOutlet var userProgram: UILabel!
    
    @IBOutlet var academiScheduleButton: UIButton!
    
    @IBOutlet var callButton: UIButton!
    
    @IBOutlet var aboutButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Main"
        
        let settingsButton:UIBarButtonItem = UIBarButtonItem(image: UIImage(named: "settingsIcon"), style: .Plain, target: self, action:#selector(MainViewController.settingsAction(_:)))
        
        self.navigationItem.rightBarButtonItem = settingsButton
        
        userName.text = userFirstName! + " " + userLastName!
        
        //Verificar este bloque
        let query = PFQuery(className:"Program")
        query.whereKey("objectId", equalTo: (user?.objectForKey("major"))!)
        query.findObjectsInBackgroundWithBlock{ (results, error) -> Void in
            
            if (error == nil) {
                
                if let programName = results {
                    
                    for program in programName {
                        
                       // self.userProgram?.text = program["program_name"] as? String
                        let userPrograms = program["program_name"] as? String
                        print(userPrograms)
                        print(program)
                    
                        
                    }
                    print(results)
                
                }
            }
        }
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func settingsAction(sender:UIBarButtonItem) {
        
        self.performSegueWithIdentifier("settingsSegue", sender: self)
        
    }
    
    @IBAction func myPoli(sender: AnyObject) {
        
        if let url = NSURL(string: "http://mypoly.pupr.edu/ics/"){
            UIApplication.sharedApplication().openURL(url)
            
        }
    }
    
    @IBAction func academicSchedule(sender: AnyObject) {
        
        if let url = NSURL(string:"https://mypoly.pupr.edu/ICS/icsfs/Academic_Calendar_for_SPRING_2016.pdf?target=bccada37-691f-4d54-97e1-2df2f9721432"){
            UIApplication.sharedApplication().openURL(url)
        }

    }
    
    
    @IBAction func callDepartment(sender: AnyObject) {
        
        let alercontroller = UIAlertController(title: "Call Department", message: "Are you sure you would like to call?", preferredStyle: .Alert)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default){
            UIAlertAction in
            
            let url:NSURL = NSURL(string: "tel://7876208000")!
            UIApplication.sharedApplication().openURL(url)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Default) {
            UIAlertAction in
        }
        
        alercontroller.addAction(okAction)
        alercontroller.addAction(cancelAction)
        
        self.presentViewController(alercontroller, animated: true, completion: nil)
    }
    
}
