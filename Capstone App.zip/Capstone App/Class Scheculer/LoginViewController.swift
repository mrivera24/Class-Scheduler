//
//  ViewController.swift
//  Class Scheculer
//


import Parse
import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var signupButton: UIButton!
    @IBOutlet var forgotPassword: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.loginButton.layer.cornerRadius = 5
        self.signupButton.layer.cornerRadius = 5
        
        self.usernameField.delegate = self
        self.passwordField.delegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Textfield delegate methods
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        self.usernameField.resignFirstResponder()
        self.passwordField.resignFirstResponder()
        
        return true
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func loginButtonTapped(sender: AnyObject) {
        
        guard let username = self.usernameField.text where !username.isEmpty else {
            
            self.showAlert(10)
            return
        }
        
        guard let password = self.passwordField.text where !password.isEmpty else {
            
            self.showAlert(11)
            return
        }
    
        PFUser.logInWithUsernameInBackground(username, password: password) { (user, error) in
            
            if (error == nil) {
                
                // Perform segue to next view controller
                self.performSegueWithIdentifier("loginSegue", sender: self)
                
            } else {
                
                if let errorCode = error?.code {
                    
                    self.showAlert(errorCode)
                }
            
            }
        }
        
        
    }

    @IBAction func signupButtonTapped(sender: AnyObject) {
    }
    
    
    
    func showAlert(error:Int) {
        
        var message:String!
        
        switch error {
        case 10:
            message = "Username field cannot be empty. Please enter your username."
            
        case 11:
            message = "Password field cannot be empty. Plese enter your password."
            
        case 101:
            message = "Invalid login parameters. Please try again."
            
        case 200:
            message = "Username is missing, please enter your username";
            
        case 201:
            message = "Password is missing, please enter your password";
            
        default:
            message = "Unknown error."
        }
        
        let alert = UIAlertController(title: "Login Error", message: message, preferredStyle: .Alert)
        let okButton = UIAlertAction(title: "OK", style: .Default, handler: nil)
        
        alert.addAction(okButton)
        
        self.presentViewController(alert, animated: true, completion: nil)
    }
    

}

