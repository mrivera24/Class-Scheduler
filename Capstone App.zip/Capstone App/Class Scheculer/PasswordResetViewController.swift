//
//  PasswordResetViewController.swift
//  Class Scheculer
//
//  Created by Miguel Rivera on 5/17/16.


import UIKit
import Parse

class PasswordResetViewController: UIViewController {

    @IBOutlet var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func resetButtonTapped(sender: AnyObject) {
        
        let emailAddress = emailTextField.text
        if emailAddress!.isEmpty
        {
            let userMessage:String = "please type in your email address"
            displayMessage(userMessage)
            return
        }
        PFUser.requestPasswordResetForEmailInBackground(emailAddress!, block: { (success:Bool, error:NSError?) -> Void in
            
            if(error != nil)
            {
                let userMessage:String = error!.localizedDescription
                self.displayMessage(userMessage)
            } else
            {
                let userMessage:String = "An email message was sent to you \(emailAddress)"
            }
            
        })

    }
    
    func displayMessage(userMessage:String){
        let myAlert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: UIAlertControllerStyle.Alert)
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
            action in
            self.dismissViewControllerAnimated(true, completion: nil)
        }
        
        myAlert.addAction(okAction)
        self.presentViewController(myAlert, animated: true, completion: nil)
    }


    @IBAction func cancelButtonTapped(sender: AnyObject) {
        
         self.dismissViewControllerAnimated(true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
