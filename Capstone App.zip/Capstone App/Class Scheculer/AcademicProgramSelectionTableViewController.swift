//
//  AcademicProgramSelectionTableViewController.swift
//  Class Scheculer
//
//

import Parse
import UIKit

@objc protocol  AcademicProgramSelectionTableViewControllerDelegate: class {
    
    optional func academicProgramSelectionDidRegisterUser(controller:AcademicProgramSelectionTableViewController)

    optional func academicProgramSelectionDidFinishUpdating(controller:AcademicProgramSelectionTableViewController)
}

class AcademicProgramSelectionTableViewController: UITableViewController {
    
    weak var delegate:AcademicProgramSelectionTableViewControllerDelegate?
    
    var academicPrograms:[AcademicPrograms] = []
    
    var user:User!
    
    var isUpdate:Bool = false
    
    var courses = [PFObject] ()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // TableView Setup
        self.title = "Academic Programs"
        
        self.loadAcademicPrograms()
        
        self.tableView.tableFooterView = UIView()
        self.tableView.allowsMultipleSelection = false
        
        if (isUpdate) {
            
            // Submit Button init
            let updateButton:UIBarButtonItem = UIBarButtonItem(title: "Update", style: .Plain, target: self, action: #selector(AcademicProgramSelectionTableViewController.updateButtonAction(_:)))
            
            //cambie submitButtonAction por updateButtonAction
            
            self.navigationItem.rightBarButtonItem = updateButton
            
        } else {
            
            // Submit Button init
            let submitButton:UIBarButtonItem = UIBarButtonItem(title: "Submit", style: .Plain, target: self, action: #selector(AcademicProgramSelectionTableViewController.submitButtonAction(_:)))
            
            self.navigationItem.rightBarButtonItem = submitButton
            
        }
    
        // Disable Submit Button until an academic program is selected
        self.navigationItem.rightBarButtonItem?.enabled = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return self.academicPrograms.count ?? 0
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = self.tableView.dequeueReusableCellWithIdentifier("programCell", forIndexPath: indexPath)
        
        cell.textLabel?.text = academicPrograms[indexPath.row].programName
        
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if let cell = tableView.cellForRowAtIndexPath(indexPath) {
            
            if cell.accessoryType == .None {
                cell.accessoryType = .Checkmark
                
                self.user.academicProgram = self.academicPrograms[indexPath.row]
                
            } else {
                cell.accessoryType = .None
            }
        }
        
        if (!self.navigationItem.rightBarButtonItem!.enabled) {
            self.navigationItem.rightBarButtonItem!.enabled = true
        }
    }
    
    override func tableView(tableView: UITableView, didDeselectRowAtIndexPath indexPath: NSIndexPath) {
        
        if let cell = tableView.cellForRowAtIndexPath(indexPath) {
            
            if (cell.accessoryType == .Checkmark) {
                cell.accessoryType = .None
            }
        }
    }

    func loadAcademicPrograms() {
        
        let query = PFQuery(className:"Program")
        query.includeKey("objectId")
        
        query.findObjectsInBackgroundWithBlock { (programs, error) in
            
            if (error == nil) {
                
                for program in programs! {
                    
                    let currentProgram = AcademicPrograms(id: program.objectId!, name: program["program_name"] as! String)
                    self.academicPrograms.append(currentProgram)
                }
                
                self.tableView.reloadData()
                
                
            } else {
                
                // - MARK: Handle Error
            }
        }
    }
    
    func submitButtonAction(sender:UIBarButtonItem) {
        
        let userToRegister = PFUser()
        
        
        userToRegister.username = self.user.email
        userToRegister.email = self.user.email
        userToRegister.password = self.user.password
        userToRegister.setObject(self.user.firstName, forKey: "first_name")
        userToRegister.setObject(self.user.lastName, forKey: "last_name")
        userToRegister["major"] = PFUser(outDataWithClassName:"Program", objectId:self.user.academicProgram.programId)
        

        
        userToRegister.signUpInBackgroundWithBlock { (success, error) in
            
            if (error == nil) {
                self.showAlertMessage(success, error: nil)
                
                let query = PFQuery(className: "Course")
                query.whereKey("course_program", equalTo: (userToRegister.objectForKey("major"))!)
                query.findObjectsInBackgroundWithBlock { (results, error) -> Void in
                    
                    if (error == nil) {
                        
                        if let returnedObjects = results {
                            
                            for courses in returnedObjects {
                                
                                self.courses.append(courses)
                                
                                
                                let userClass:PFObject = PFObject(className: "User_Courses")
                                userClass.setObject(courses, forKey: "courseId")
                                userClass.setObject(PFUser.currentUser()!, forKey: "userId")
                                userClass.setObject(0, forKey: "Completed")
                                                userClass.saveInBackgroundWithBlock { (succeeded, error) -> Void in
                                
                                                   if succeeded {
                                
                                                        print("Lo guardo")
                        
                                                    
                                                    }else{
                                                    
                                                        print("error")
                                                    }
                                                }

                                
                            }
                        }
                
                    }
                    
                }
                
            } else {
                self.showAlertMessage(success, error: error?.code)
            }

        }
    }
    
    
    func updateButtonAction(sender:UIBarButtonItem) {
        
        let user = PFUser.currentUser()
        user!["major"] = PFUser(outDataWithClassName:"Program", objectId:self.user.academicProgram.programId)
        
        user?.saveInBackgroundWithBlock { (success, error) in
            
            if (error == nil) {
                
                self.showUpdateMessage (success, error: nil)
            } else {
                self.showUpdateMessage(success, error: error?.code)
            }
        }
        
    }
    
    
    func showAlertMessage(success:Bool, error:Int?) {
        
        var title = "Class Scheduler"
        var message = "Generic message."
        
        if (success) {
            
            title = "Welcome"
            message = "Registration was sucessful. Please procede to log in."
            
            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
            
            let okButton = UIAlertAction(title: "OK", style: .Default, handler: { (action) in
                
                self.delegate?.academicProgramSelectionDidRegisterUser!(self)
            })
            
            alert.addAction(okButton)
            
            self.presentViewController(alert, animated: true, completion: nil)
            
        } else if (!success && error != nil) {
            
            title = "Error"
            message = "Registration error. Please try again."
            
            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
            
            let okButton = UIAlertAction(title: "OK", style: .Default, handler: { (action) in
                
                //self.delegate?.academicProgramSelectionDidRegisterUser(self)
            })
            
            alert.addAction(okButton)
            
            self.presentViewController(alert, animated: true, completion: nil)
            
        }
        
    }
    
    
    func showUpdateMessage(success:Bool, error:Int?) {
        
        var title = "Class Scheduler"
        var message = "Generic message."
        
        if (success) {
            
            title = "Congratulations!"
            message = "The update was sucessful."
            
            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
            
            let okButton = UIAlertAction(title: "OK", style: .Default, handler: { (action) in
                
               // self.delegate?.academicProgramSelectionDidRegisterUser!(self)
                self.delegate?.academicProgramSelectionDidFinishUpdating!(self)
            })
            
            alert.addAction(okButton)
            
            self.presentViewController(alert, animated: true, completion: nil)
            
        } else if (!success && error != nil) {
            
            title = "Error"
            message = "Updating program error. Please try again."
            
            let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
            
            let okButton = UIAlertAction(title: "OK", style: .Default, handler: { (action) in
                
                //self.delegate?.academicProgramSelectionDidRegisterUser(self)
            })
            
            alert.addAction(okButton)
            
            self.presentViewController(alert, animated: true, completion: nil)
            
        }
    }



}
