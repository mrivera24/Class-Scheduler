//
//  SettingsTableViewController.swift
//  Class Scheculer
//


import Parse
import UIKit

class SettingsTableViewController: UITableViewController, AcademicProgramSelectionTableViewControllerDelegate {
    
    var window: UIWindow?
    
    let user = PFUser.currentUser()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Settings"
        
        self.tableView.sectionFooterHeight = 0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 2
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var rows:Int = 0
        
        if (section == kSettingsProfileSectionIndex) {
            rows = kSettingsTotalProfileRows
            
        } else if (section == kSettingsLogoutSectionIndex) {
            rows =  kSettingsTotalLogoutRows
        }

        return rows
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        
        if (indexPath.section == kSettingsProfileSectionIndex) {
            
            var cell = tableView.dequeueReusableCellWithIdentifier(kProfileCellidentifier)
            
            if (cell == nil) {
                
                cell = UITableViewCell(style: .Default, reuseIdentifier: kProfileCellidentifier)
            }
            
            if (indexPath.row == kSettingsProfileRowChangeEmailIndex) {
                
                cell?.textLabel?.text = "Change Email"
                cell?.accessoryType = .DisclosureIndicator
                
                return cell!
                
            } else if (indexPath.row == kSettingsProfileRowChangePasswordIndex ){
                
                cell?.textLabel?.text = "Change Password"
                cell?.accessoryType = .DisclosureIndicator
                
                return cell!
                
            } else if (indexPath.row == kSettingsProfileRowChangeAcademicProgramIndex) {
                
                cell?.textLabel?.text = "Change Academic Program"
                cell?.accessoryType = .DisclosureIndicator
                
                return cell!
            }
            
        }
        
        if (indexPath.section == kSettingsLogoutSectionIndex) {
            
            var cell = tableView.dequeueReusableCellWithIdentifier(kLogoutCellidentidier)
            
            if (cell == nil) {
                
                cell = UITableViewCell(style: .Default, reuseIdentifier: kLogoutCellidentidier)
            }
            
            if (indexPath.row == kSettingsLogoutRowIndex) {
                
                cell?.textLabel?.text = "Log Out"
                cell?.textLabel?.textColor = UIColor.redColor()
                
                return cell!
            }
        }
        
        var cell = tableView.dequeueReusableCellWithIdentifier(kCellidentifier)
        
        if (cell == nil) {
            cell = UITableViewCell(style: .Default, reuseIdentifier: kCellidentifier)
        }
        
        return cell!
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        var header:String = ""
        
        if (section == kSettingsProfileSectionIndex) {
            
            header = "Account"
        }
        
        return header
    }
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 40
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if (indexPath.section == kSettingsLogoutSectionIndex && indexPath.row == kSettingsLogoutRowIndex) {
            
            self.logoutUser()
            
        }
        
        
        if (indexPath.section == kSettingsProfileSectionIndex) {
            
            if (indexPath.row == kSettingsProfileRowChangeAcademicProgramIndex) {
                
                // Perfom segue to academic programs VC
                performSegueWithIdentifier("updateAcademicProgram", sender: self)
                
            }else if (indexPath.row == kSettingsProfileRowChangeEmailIndex) {
                
                performSegueWithIdentifier("changeEmail", sender: self)
//                
//                
            } else if (indexPath.row == kSettingsProfileRowChangePasswordIndex) {
                
                performSegueWithIdentifier("changePassword", sender: self)
//                
            }
                
            
        }
    }
    
    func logoutUser() {
        
        let title = "Are you sure?"
        let message = ""
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        
        let okButton = UIAlertAction(title: "Log out", style: .Default) { (action) in
            
            PFUser.logOutInBackground()
            
            let storyBoard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
            
            let loginViewController = storyBoard.instantiateViewControllerWithIdentifier("loginVC")
    
            UIApplication.sharedApplication().keyWindow?.rootViewController = loginViewController

        }
        
        let cancelButton = UIAlertAction(title: "Cancel", style: .Cancel, handler: nil)
        
        alert.addAction(okButton)
        alert.addAction(cancelButton)
        
        self.presentViewController(alert, animated: true, completion: nil)
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if (segue.identifier == "updateAcademicProgram") {
            
            let academicProgramVC = segue.destinationViewController as! AcademicProgramSelectionTableViewController
            
            academicProgramVC.user = User(parseUser: self.user!)
            academicProgramVC.isUpdate = true
            academicProgramVC.delegate = self
        }else if (segue.identifier == "changeEmail") {
            
            let changeEmailVC = segue.destinationViewController as! userEmailUpdateViewController
            self.navigationController?.popViewControllerAnimated(true)
            
        }else if (segue.identifier == "changePassword") {
            
            let changePasswordVC = segue.destinationViewController as! userPasswordUpdateViewController
            self.navigationController?.popViewControllerAnimated(true)
        }
    }
    
    func academicProgramSelectionDidFinishUpdating(controller: AcademicProgramSelectionTableViewController) {
        
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    

}
