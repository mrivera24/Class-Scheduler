//
//  AcademicPrograms.swift
//  Class Scheculer
//


import UIKit

class AcademicPrograms: NSObject {
    
    var programId:String = ""
    var programName:String = ""
    
    init (id:String, name:String) {
        
        self.programId = id
        self.programName = name
    }

}
